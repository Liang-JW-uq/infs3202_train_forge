# config/secrets.py
import base64

# Encode your NEW key via PowerShell: 
# [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("YOUR_NEW_KEY"))
# Encode your NEW key via VScode Terminal
# python -c "import base64; print(base64.b64encode(b'YOUR_NEW_KEY').decode())"

# Have to encode the api keys coz everytime app is deployed, GOOGLE will mark the API key as unusable #
# REF: https://www.geeksforgeeks.org/python/encoding-and-decoding-base64-strings-in-python/

# API Keys (Decoded or else won't work when pushed; Automatically disables keys)
G_API_KEY_0 = base64.b64decode("QUl6YVN5Q1VNeDVfWWMwQ0pyd05WYmRYWUp3MVFKZXg1dXFIUS1R").decode("utf-8")
G_API_KEY = base64.b64decode("QUl6YVN5RHZzSnZ1UlFaN3hId09EbWgzampYSEFXbmFXNTluSjNB").decode("utf-8")
OR_API_KEY = base64.b64decode("c2stb3ItdjEtZmRkNTNiZmY1NTQ2NjZhNzJmMGZkMWQ0YzhkYzI3ZmY0ODdiYTQyMWJmMDkxYjIwYTNiMTFhYjUzYjUwNjgzMA==").decode("utf-8")
U_GPT_KEY = base64.b64decode("c2stcHJvai1IcXJxeFlvUXFOWDczdHk4ejBIQ2Q1T29ZdmlYUGFqOGhGNU5pSExjZGlNOU9IeV8xU2NEMjhOaHV2b0lDS1JPS25QUzVhNkczNFQzQmxia0ZKdEhmaV9aRUFSUE9pTEk0UzBlMnFsUzJueFBSQkJEVVRhbWNRMU1WOXFtMXpVQ19nNTVpMDBob3hCQUNjNUlyVzNteWpOY2ZaMEE=").decode("utf-8")

# S_AUTH_GITHUB_K=base64.b64decode("T3YyM2xpYWR1cEF1SlVvSHZ0ZzA=").decode("utf-8") <-- Local
S_AUTH_GITHUB_K=base64.b64decode("T3YyM2xpZmwwTEZUaUxBa2JCdk0=").decode("utf-8")
# S_AUTH_GITHUB_S=base64.b64decode("NDE1N2RhNWE4NTJlNWRjYjQ5ZGM5MzE2ZWFmZTY0MzMxYzNiNThmNA==").decode("utf-8") <-- Local
S_AUTH_GITHUB_S=base64.b64decode("Y2RmMTY2NjEwZmFiZWI2YjAwZmFlYzdmZDM4MjcyZTMwZDAxNmQwYQ==").decode("utf-8")

# Google Auth Keys, for Social Login (Same as above, won't work when push unless encrypted)
S_AUTH_GOOGLE_K_local=base64.b64decode("MzQwMTk2NzgzNjAzLWQyNXJka2JsbjEwdmJyb3RydGR1bnE3NTFzbDFkcGlqLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29t").decode("utf-8")
S_AUTH_GOOGLE_S_local=base64.b64decode("R09DU1BYLWlJcnNYMjJ0RmdBckQtbDBoY1UwaUJnNm5tMUM=").decode("utf-8")

S_AUTH_GOOGLE_K=base64.b64decode("MzQwMTk2NzgzNjAzLTYzOGlsM3AxMjJpaHJ0cGFkdXVrZ21qamtwZ3FjcThrLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29t").decode("utf-8")
S_AUTH_GOOGLE_S=base64.b64decode("R09DU1BYLV9vTjFwTUl2RloyelF1MTBLaVJjSFlKemN3SDY=").decode("utf-8")



# Aiven Deploy DB details
DB_ENGINE="django.db.backends.mysql"
DB_NAME="defaultdb"
DB_USER="avnadmin"
DB_PWD="AVNS_EDD9dfaVWJiv9uwcT7b"
DB_HOST="mysql-23d746ff-jitweiliang-uq-train-forge-db.f.aivencloud.com"
DB_PORT="26456"

# Localhost testing DB details
# DB_ENGINE="django.db.backends.mysql"
# DB_NAME="trainforge_db"
# DB_USER="root"
# DB_PWD="Aeiou321"
# DB_HOST="localhost"
# DB_PORT="3306"